World Cup 2026 Sweep Website

How to share:
1. Upload this folder to Netlify Drop, Vercel, GitHub Pages, or any static web host.
2. Open index.html locally to test.
3. Scores and uploaded face photos are saved in each viewer's browser localStorage. For one shared live source of truth, connect the score data to a database such as Firebase/Supabase.

Fixture updates:
- The site includes a starter AEST fixture list based on publicly available fixture listings.
- Use the Match Schedule tab to import a JSON fixture file with fields: date, group, home, away, venue.
